#include "TicTacToe.h"

//I tried to make it too big and wasnt able to complete it in the time frame.

//pretty fullfeatured, by default prompts user for decisions on various rule choices (how many rows, how many columns, etc.).
//allows for multiple players and custom length in a row to win.

using namespace std;

int main(int argc, char const *argv[])
{
	TicTacToe game;
	game.play();

}
